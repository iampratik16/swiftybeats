SWIFTY BEATS — "FREEDOM" PRESS KIT
Industry use only. Management: info@supremuemusic.group

Contents:
- Freedom-cover.avif       Single cover artwork
- swifty-portrait.jpg      Artist portrait
- press-studio / festival / dhol   Press photos

Audio: streaming/download links available on request.
